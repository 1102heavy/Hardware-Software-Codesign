/* 
----------------------------------------------------------------------------------
--  (c) Rajesh C Panicker, NUS
--  Description : Matrix Multiplication AXI Stream Coprocessor. Based on the orginal AXIS Coprocessor template (c) Xilinx Inc
--   Based on the orginal AXIS coprocessor template (c) Xilinx Inc
--  License terms :
--  You are free to use this code as long as you
--    (i) DO NOT post a modified version of this on any public repository;
--    (ii) use it only for educational purposes;
--    (iii) accept the responsibility to ensure that your implementation does not violate any intellectual property of any entity.
--    (iv) accept that the program is provided "as is" without warranty of any kind or assurance regarding its suitability for any particular purpose;
--    (v) send an email to rajesh.panicker@ieee.org briefly mentioning its use (except when used for the course EE4218 at the National University of Singapore);
--    (vi) retain this notice in this file or any files derived from this.
----------------------------------------------------------------------------------
*/
/*
-------------------------------------------------------------------------------
--
-- Definition of Ports
-- ACLK           : Synchronous clock
-- ARESETN        : System reset, active low
-- S_AXIS_TREADY  : Ready to accept data in
-- S_AXIS_TDATA   : Data in 
-- S_AXIS_TLAST   : Optional data in qualifier
-- S_AXIS_TVALID  : Data in is valid
-- M_AXIS_TVALID  : Data out is valid
-- M_AXIS_TDATA   : Data Out
-- M_AXIS_TLAST   : Optional data out qualifier
-- M_AXIS_TREADY  : Connected slave device is ready to accept data out
--
-------------------------------------------------------------------------------
*/

module myip_v1_0 
  (
    // DO NOT EDIT BELOW THIS LINE ////////////////////
    ACLK,
    ARESETN,
    S_AXIS_TREADY,
    S_AXIS_TDATA,
    S_AXIS_TLAST,
    S_AXIS_TVALID,
    M_AXIS_TVALID,
    M_AXIS_TDATA,
    M_AXIS_TLAST,
    M_AXIS_TREADY

    // DO NOT EDIT ABOVE THIS LINE ////////////////////
  );

  input          ACLK;    // Synchronous clock
  input          ARESETN; // System reset, active low
  // slave in interface
  output  reg        S_AXIS_TREADY;  // Ready to accept data in
  input  [31 : 0]    S_AXIS_TDATA;   // Data in
  input          S_AXIS_TLAST;   // Optional data in qualifier
  input          S_AXIS_TVALID;  // Data in is valid
  // master out interface
  output  reg        M_AXIS_TVALID;  // Data out is valid
  output  reg [31 : 0]  M_AXIS_TDATA;   // Data Out
  output  reg        M_AXIS_TLAST;   // Optional data out qualifier
  input          M_AXIS_TREADY;  // Connected slave device is ready to accept data out
    
//----------------------------------------
// Implementation Section
//----------------------------------------
// In this section, we povide an example implementation of MODULE myip_v1_0
// that does the following:
//
// 1. Read all inputs
// 2. Add each input to the contents of register 'sum' which acts as an accumulator
// 3. After all the inputs have been read, write out the content of 'sum', 'sum+1', 'sum+2', 'sum+3'
//
// You will need to modify this example for
// MODULE myip_v1_0 to implement your coprocessor

// RAM parameters for assignment 1
//test 1
  localparam A_depth_bits = 9;    // 8 elements (A is a 2x4 matrix)
  localparam B_depth_bits = 3;   // 4 elements (B is a 4x1 matrix)
  localparam RES_depth_bits = 6;  // 2 elements (RES is a 2x1 matrix)

// test 2  
//    localparam A_depth_bits   = 9;   // 512 elements (A is 64x8)
//    localparam B_depth_bits   = 3;   // 8 elements  (B is 8x1)
//    localparam RES_depth_bits = 6;   // 64 elements  (RES is 64x1)


  localparam width = 8;      // all 8-bit data
  
// wires (or regs) to connect to RAMs and matrix_multiply_0 for assignment 1
// those which are assigned in an always block of myip_v1_0 shoud be changes to reg.
  reg  A_write_en;                // myip_v1_0 -> A_RAM. To be assigned within myip_v1_0. Possibly reg.
  reg  [A_depth_bits-1:0] A_write_address;    // myip_v1_0 -> A_RAM. To be assigned within myip_v1_0. Possibly reg. 
  reg  [width-1:0] A_write_data_in;      // myip_v1_0 -> A_RAM. To be assigned within myip_v1_0. Possibly reg.
  wire  A_read_en;                // matrix_multiply_0 -> A_RAM.
  wire  [A_depth_bits-1:0] A_read_address;    // matrix_multiply_0 -> A_RAM.
  wire  [width-1:0] A_read_data_out;      // A_RAM -> matrix_multiply_0.
  reg  B_write_en;                // myip_v1_0 -> B_RAM. To be assigned within myip_v1_0. Possibly reg.
  reg  [B_depth_bits-1:0] B_write_address;    // myip_v1_0 -> B_RAM. To be assigned within myip_v1_0. Possibly reg.
  reg  [width-1:0] B_write_data_in;      // myip_v1_0 -> B_RAM. To be assigned within myip_v1_0. Possibly reg.
  wire  B_read_en;                // matrix_multiply_0 -> B_RAM.
  wire  [B_depth_bits-1:0] B_read_address;    // matrix_multiply_0 -> B_RAM.
  wire  [width-1:0] B_read_data_out;      // B_RAM -> matrix_multiply_0.
  wire  RES_write_en;              // matrix_multiply_0 -> RES_RAM.
  wire  [RES_depth_bits-1:0] RES_write_address;  // matrix_multiply_0 -> RES_RAM.
  wire  [width-1:0] RES_write_data_in;      // matrix_multiply_0 -> RES_RAM.
  reg  RES_read_en;                // myip_v1_0 -> RES_RAM. To be assigned within myip_v1_0. Possibly reg.
  reg  [RES_depth_bits-1:0] RES_read_address;  // myip_v1_0 -> RES_RAM. To be assigned within myip_v1_0. Possibly reg.
  wire  [width-1:0] RES_read_data_out;      // RES_RAM -> myip_v1_0
  
  // wires (or regs) to connect to matrix_multiply for assignment 1
    reg  Start = 0;                 // myip_v1_0 -> matrix_multiply_0. To be assigned within myip_v1_0. Possibly reg.
    reg Start_Sent;
    wire  Done;                // matrix_multiply_0 -> myip_v1_0. 
  
  //Total numer of input data of A
  localparam   NUMBER_OF_INPUT_WORDS_A = 1 << A_depth_bits;
  
  //Total numer of input data of B
  localparam   NUMBER_OF_INPUT_WORDS_B = 1 << B_depth_bits;
        
  // Total number of input data.
  localparam NUMBER_OF_INPUT_WORDS  = (NUMBER_OF_INPUT_WORDS_A + NUMBER_OF_INPUT_WORDS_B); // 2**A_depth_bits + 2**B_depth_bits = 12 for assignment 1

  // Total number of output data
  localparam NUMBER_OF_OUTPUT_WORDS = (1 << RES_depth_bits); // 2**RES_depth_bits = 2 for assignment 1

  // Define the states of state machine (one hot encoding)
  localparam Idle  = 4'b1000;
  localparam Read_Inputs = 4'b0100;
  localparam Compute = 4'b0010;
  localparam Write_Outputs  = 4'b0001;

  reg [3:0] next_state = 4'b1000;
  reg [3:0] current_state = 4'b1000;
  reg read_counter_en =0;
  reg write_counter_en=0;
  reg read_counter_rst =0;
  reg write_counter_rst=0;


  // Accumulator to hold sum of inputs read at any point in time

  // Counters to store the number inputs read & outputs written.
  // Could be done using the same counter if reads and writes are not overlapped (i.e., no dataflow optimization)
  // Left as separate for ease of debugging
  reg [$clog2(NUMBER_OF_INPUT_WORDS) - 1:0] read_counter =0;
  reg [$clog2(NUMBER_OF_OUTPUT_WORDS):0] write_counter=0;

   // CAUTION:
   // The sequence in which data are read in and written out should be
   // consistent with the sequence they are written and read in the driver's hw_acc.c file
  always @(posedge ACLK) 
  begin
    current_state <= next_state;
    if(read_counter_en ==1)
    begin
        read_counter <= read_counter+1;
//        read_counter_en<=0;
    end
    
    if(read_counter_rst==1)
    begin
        read_counter <= 0;
//        read_counter_rst <= 0;
//        read_counter_en<=0;
    end
    
    if(write_counter_en==1)
    begin
        write_counter <=write_counter+1;
//        write_counter_en<=0;
    end
    
    if(write_counter_rst==1)
    begin
        write_counter <= 0;
//        write_counter_rst <= 0;
//        read_counter_en<=0;
    end
    
  end
  
  always @(*) // state
  begin
  // implemented as a single-always Moore machine
  // a Mealy machine that asserts S_AXIS_TREADY and captures S_AXIS_TDATA etc can save a clock cycle
  
  /****** Synchronous reset (active low) ******/
    if (!ARESETN)
    begin
      // CAUTION: make sure your reset polarity is consistent with the system reset polarity
    next_state        = Idle;
    end
    else
    begin
      next_state        = Idle;
      
      case (current_state)
        Idle:
        begin
          if (S_AXIS_TVALID == 1)
          begin
            next_state         = Read_Inputs;
          end
          else begin
            next_state = Idle;
          end
        end

        Read_Inputs:
        begin      
            if (read_counter >= NUMBER_OF_INPUT_WORDS-1)
                begin
                    next_state = Compute;
                end
            else begin
                next_state = Read_Inputs;
            end
        end
        Compute:
        begin
          // Coprocessor function to be implemented (matrix multiply) should be here. Right now, nothing happens here.
          //Wait for the calculation to be done and then transition to Write outputs
          if (!Done) begin
             next_state = Compute;
          end 
          else if (M_AXIS_TREADY == 1) begin    
             next_state = Write_Outputs; 
          end else begin
            next_state = Compute;
          end
          // Possible to save a cycle by asserting M_AXIS_TVALID and presenting M_AXIS_TDATA just before going into 
          // Write_Outputs state. However, need to adjust write_counter limits accordingly
          // Alternatively, M_AXIS_TVALID and M_AXIS_TDATA can be asserted combinationally to save a cycle.
        end

          
        Write_Outputs:
        begin
          // Coprocessor function (adding 1 to sum in each iteration = adding iteration count to sum) happens here (partly)
             
            if (write_counter >= NUMBER_OF_OUTPUT_WORDS)
            begin
              next_state  = Idle;
            end
            else begin
                next_state = Write_Outputs;
            end

        end
        default: next_state = Idle;
      endcase
    end
 end
    
always @(*) // outputs
  begin
     
  // implemented as a single-always Moore machine
  // a Mealy machine that asserts S_AXIS_TREADY and captures S_AXIS_TDATA etc can save a clock cycle
  
  /****** Synchronous reset (active low) ******/
//    if (!ARESETN)
//    begin
//      // CAUTION: make sure your reset polarity is consistent with the system reset polarity
//      next_state        = Idle;
//    end
//    else
//    begin
      M_AXIS_TDATA  =0;
      M_AXIS_TVALID   = 0;
      M_AXIS_TLAST    = 0;
      S_AXIS_TREADY   = 0; 
      
      write_counter_en   =0;
      write_counter_rst  =0;
      
      read_counter_en=0;
      read_counter_rst   = 0;
         
      A_write_en = 0;
      A_write_address =0;
      A_write_data_in = 0;
        
      B_write_en = 0;
      B_write_address = 0;
      B_write_data_in = 0; //Discard rest of the 32 bits   
      
      RES_read_en = 0;
      RES_read_address = 0;
      
      Start = 0;
      
      case (current_state)
        Idle:
        begin
          M_AXIS_TDATA  =0;
          M_AXIS_TVALID   = 0;
          M_AXIS_TLAST    = 0;
          S_AXIS_TREADY   = 0; 
          
          write_counter_en   =0;
          write_counter_rst  =0;
          
          read_counter_en=0;
          read_counter_rst   = 0;
             
          A_write_en = 0;
          A_write_address =0;
          A_write_data_in = 0;
            
          B_write_en = 0;
          B_write_address = 0;
          B_write_data_in = 0; //Discard rest of the 32 bits   
          
          RES_read_en = 0;
          RES_read_address = 0;
          
          Start = 0;
          
          if (S_AXIS_TVALID == 1)
          begin
            S_AXIS_TREADY   = 1; 
            A_write_en = 1;
            A_write_address = read_counter;
            A_write_data_in = S_AXIS_TDATA [7:0];
            //read_counter_en=1;
          end
        end

        Read_Inputs:
        begin
            M_AXIS_TDATA  =0;
            M_AXIS_TVALID   = 0;
            M_AXIS_TLAST    = 0;
            S_AXIS_TREADY   = 1; 
            
            write_counter_en   =0;
            write_counter_rst  =0;
            
            read_counter_en=1;
            read_counter_rst   = 0;
            
            A_write_en = 0;
            A_write_address =0;
            A_write_data_in = 0;
            
            B_write_en = 0;
            B_write_address = 0;
            B_write_data_in = 0; //Discard rest of the 32 bits   
            
            RES_read_en = 0;
            RES_read_address = 0;
            
            Start = 0;
//             If we are expecting a variable number of words, we should make use of S_AXIS_TLAST.
//             Since the number of words we are expecting is fixed, we simply count and receive 
//             the expected number (NUMBER_OF_INPUT_WORDS) instead.

//                        start Receiving data
//                        Starting with A then B                                                          
//                        First 2**3 words correspond to A then next 2**2 can correspond to B in row major order
            if (read_counter < NUMBER_OF_INPUT_WORDS_A-1)
                begin
                                        
                    A_write_en = 1;
                    A_write_address = read_counter+1;
                    A_write_data_in = S_AXIS_TDATA [7:0];

                      //Fill in A matrix

                end
            else if (read_counter < NUMBER_OF_INPUT_WORDS-1)
                begin                    
                    B_write_en = 1;
                    B_write_address = (read_counter+1 - NUMBER_OF_INPUT_WORDS_A);
                    B_write_data_in = S_AXIS_TDATA [7:0]; //Discard rest of the 32 bits   
                    
                
                end
            
            else if (read_counter >= NUMBER_OF_INPUT_WORDS-1)
                begin
                    S_AXIS_TREADY   = 0;
                    read_counter_rst   = 1;
                    read_counter_en = 0;
                    Start =1;
                                                               

                end
        end
        
        Compute:
        begin
            M_AXIS_TDATA  =0;
            M_AXIS_TVALID   = 0;
            M_AXIS_TLAST    = 0;
            S_AXIS_TREADY   = 0; 
            
            write_counter_en   =0;
            write_counter_rst  =0;
            
            read_counter_en=0;
            read_counter_rst   = 0;
            
            A_write_en = 0;
            A_write_address =0;
            A_write_data_in = 0;
            
            B_write_en = 0;
            B_write_address = 0;
            B_write_data_in = 0; //Discard rest of the 32 bits   
            
            RES_read_en = 0;
            RES_read_address = 0;
            
            
            // Coprocessor function to be implemented (matrix multiply) should be here. Right now, nothing happens here.
            //Wait for the calculation to be done and then transition to Write outputs
            if (!Done) begin
                Start =1;
            end 
            else if (M_AXIS_TREADY == 1) begin
                RES_read_en = 1;
                //             RES_write_en <= 0;
                RES_read_address = write_counter;
                write_counter_en =1;
                Start = 0;
            end

            // Possible to save a cycle by asserting M_AXIS_TVALID and presenting M_AXIS_TDATA just before going into 
            // Write_Outputs state. However, need to adjust write_counter limits accordingly
            // Alternatively, M_AXIS_TVALID and M_AXIS_TDATA can be asserted combinationally to save a cycle.
            end
            
          
        Write_Outputs:
        begin
            M_AXIS_TDATA  =0;
            M_AXIS_TVALID   = 0;
            M_AXIS_TLAST    = 0;
            S_AXIS_TREADY   = 0; 
            
            write_counter_en   =0;
            write_counter_rst  =0;
            
            read_counter_en=0;
            read_counter_rst   = 0;
            
            A_write_en = 0;
            A_write_address =0;
            A_write_data_in = 0;
            
            B_write_en = 0;
            B_write_address = 0;
            B_write_data_in = 0; //Discard rest of the 32 bits   
            
//            RES_read_en = 0;
//            RES_read_address = 0;
            
            Start = 0;
          // Coprocessor function (adding 1 to sum in each iteration = adding iteration count to sum) happens here (partly)

                  // M_AXIS_TLAST, though optional in AXIS, is necessary in practice as AXI Stream FIFO and AXI DMA expects it.
            M_AXIS_TDATA  = RES_read_data_out;
//            M_AXIS_TDATA  = write_counter;
            RES_read_en = 1;
            RES_read_address = write_counter;
            M_AXIS_TVALID  = 1;                        
            if (write_counter >= NUMBER_OF_OUTPUT_WORDS)
            begin
                M_AXIS_TLAST  = 1;
                write_counter_en   =0;
                write_counter_rst  =1;
            end
            else begin
                M_AXIS_TLAST  = 0;
                write_counter_en   =1;
                write_counter_rst  =0;
            end
            

        end
      endcase
    end
    
//  end
     
  // Connection to sub-modules / components for assignment 1
  
  memory_RAM 
  #(
    .width(width), 
    .depth_bits(A_depth_bits)
  ) A_RAM 
  (
    .clk(ACLK),
    .write_en(A_write_en),
    .write_address(A_write_address),
    .write_data_in(A_write_data_in),
    .read_en(A_read_en),    
    .read_address(A_read_address),
    .read_data_out(A_read_data_out)
  );
                    
                    
  memory_RAM 
  #(
    .width(width), 
    .depth_bits(B_depth_bits)
  ) B_RAM 
  (
    .clk(ACLK),
    .write_en(B_write_en),
    .write_address(B_write_address),
    .write_data_in(B_write_data_in),
    .read_en(B_read_en),    
    .read_address(B_read_address),
    .read_data_out(B_read_data_out)
  );
                    
                    
  memory_RAM 
  #(
    .width(width), 
    .depth_bits(RES_depth_bits)
  ) RES_RAM 
  (
    .clk(ACLK),
    .write_en(RES_write_en),
    .write_address(RES_write_address),
    .write_data_in(RES_write_data_in),
    .read_en(RES_read_en),    
    .read_address(RES_read_address),
    .read_data_out(RES_read_data_out)
  );
                    
  matrix_multiply 
  #(
    .width(width), 
    .A_depth_bits(A_depth_bits), 
    .B_depth_bits(B_depth_bits), 
    .RES_depth_bits(RES_depth_bits) 
  ) matrix_multiply_0
  (                  
    .clk(ACLK),
    .Start(Start),
    .Done(Done),
    
    .A_read_en(A_read_en),
    .A_read_address(A_read_address),
    .A_read_data_out(A_read_data_out),
    
    .B_read_en(B_read_en),
    .B_read_address(B_read_address),
    .B_read_data_out(B_read_data_out),
    
    .RES_write_en(RES_write_en),
    .RES_write_address(RES_write_address),
    .RES_write_data_in(RES_write_data_in)
  );

endmodule            
                                       
